Deepin Music Player
=============================

A simple player for you.
